
package echoserver;

import java.net.*;
import java.io.*;


import org.quickserver.net.server.ClientCommandHandler;
import org.quickserver.net.server.ClientHandler;
import org.quickserver.net.server.ClientEventHandler;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.ws.AsyncHandler;


public class EchoCommandHandler implements ClientCommandHandler, ClientEventHandler {
	//private static Logger logger = 	Logger.getLogger(EchoCommandHandler.class.getName());

	//--ClientEventHandler
	public void gotConnected(ClientHandler handler)
		throws SocketTimeoutException, IOException {
		//logger.fine("Connection opened : "+handler.getHostAddress());
		System.out.println("Connection opened : "+handler.getHostAddress());
		/*handler.sendClientMsg("+++++++++++++++++++++++++++++++");
		handler.sendClientMsg("| Welcome to EchoServer v " + EchoServer.version+" |");
		handler.sendClientMsg("|  Note: Password = Username  |");
		handler.sendClientMsg("|        Send 'Quit' to exit  |");
		handler.sendClientMsg("+++++++++++++++++++++++++++++++");*/
	}

	public void lostConnection(ClientHandler handler) 
		throws IOException {
		handler.sendSystemMsg("Connection lost : "+	handler.getSocket().getInetAddress(), Level.FINE);
	}
	
	public void closingConnection(ClientHandler handler) throws IOException {
		System.out.println("Connection closed : "+handler.getSocket().getInetAddress());		
	}
	//--ClientEventHandler

	public void handleCommand(ClientHandler handler, String deviceResponse)
			throws SocketTimeoutException, IOException {
		System.out.println("Client Command : "+ deviceResponse);
		
		System.out.println(handler.getHostAddress().toString() + " : "+ deviceResponse);
        //System.out.println("echo: " + m.group());
       
        Pattern p = Pattern.compile("\\$+\\$.*");
        Matcher matcher = p.matcher(deviceResponse);
        /*if(matcher.find()){
            String deviceStr = matcher.group(0);
            //System.out.println("deviceStr: " + deviceStr);
            String[] deviceInfoArr;
            String[] latonArr;
            String Deviceid    = "";
            String datetime = null;
            String latitude = "";
            String longitude= "";
           
            deviceInfoArr    = deviceStr.split("\\|");
            if(deviceInfoArr.length>5){
                latonArr    = deviceInfoArr[0].split("\\,");
               
               
                Deviceid    = deviceInfoArr[5];
                Deviceid    = Deviceid.substring(0,6);
               
                if(latonArr.length>4){
                    latitude    = latonArr[2];
                    longitude    = latonArr[4];
                   
                    if(!latitude.substring(0,4).equals("0000") && !longitude.substring(0,5).equals("00000")){
                   
                        String datetimeStr     = "0000-00-00 00:00:00";
                        //String datetimeStr     = deviceInfoArr[6];
                        //System.out.println("datetimeStr :"+datetimeStr);
                       
                                                 
                       
                        System.out.println("Deviceid :"+Deviceid);
                        System.out.println("Latitude :"+latitude);
                        System.out.println("Longitude :"+longitude);
                        System.out.println("Datetime :"+datetimeStr);      
                       
                        String strLa=latitude;
                          String strLo=longitude;
                         
                          String strLo1="",strlo2="",strLa1="",strla2;
                          String SN="N",WE="E";
                          strLa1=strLa.substring(0, 2);
                          strla2=strLa.substring(2);
                          System.out.println(strLo1);
                          double la=Integer.parseInt(strLa1)+Double.parseDouble(strla2)/60;
                          System.out.println(la);
                          strLo1=strLo.substring(0, 3);
                          strlo2=strLo.substring(3);
                          double lo=Integer.parseInt(strLo1)+Double.parseDouble(strlo2)/60;
                           System.out.println(lo);
                       
                        Statement st;
                        try {                               
                            st = connection.createStatement();
                            int val = st.executeUpdate("INSERT INTO gpsdata(deviceid, latitude, longitude, posdatetime) VALUES('" + Deviceid + "','" + la + "','" + lo + "','" + datetimeStr + "')");
                            System.out.println("1 row Insertted");
                        } catch (SQLException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }  
                    }
                }                         
              
            }
        }*/
       
        if(matcher.find()){
            String deviceStr = matcher.group(0);
            //System.out.println("deviceStr: " + deviceStr);
            String[] deviceInfoArr;
            String[] latonArr;
            String Deviceid    = "";
            String datetime = null;
            String latitude = "";
            String longitude= "";
           
            deviceInfoArr    = deviceStr.split("\\|");
            Deviceid    = deviceInfoArr[0].replace("$","");
            Deviceid    = Deviceid.substring(2);
            latonArr    = deviceInfoArr[1].split("\\,");
            if(latonArr.length>5){
                latitude    = latonArr[3];
                longitude    = latonArr[5];
               
                String datetimeStr     = deviceInfoArr[6];
                //System.out.println("datetimeStr :"+datetimeStr);
               
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");                       
                try {
                    java.util.Date datetimeC = dateFormat.parse(datetimeStr);
                    SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    datetime = sdf.format(datetimeC);

                } catch (ParseException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }                                             
               
               
                System.out.println("Deviceid :"+Deviceid);
                System.out.println("Latitude :"+latitude);
                System.out.println("Longitude :"+longitude);
                System.out.println("Datetime :"+datetime);      
               
                String strLa=latitude;
                  String strLo=longitude;
                 
                  String strLo1="",strlo2="",strLa1="",strla2;
                  String SN="N",WE="E";
                  strLa1=strLa.substring(0, 2);
                  strla2=strLa.substring(2);
                  System.out.println(strLo1);
                  double la=Integer.parseInt(strLa1)+Double.parseDouble(strla2)/60;
                  System.out.println(la);
                  strLo1=strLo.substring(0, 3);
                  strlo2=strLo.substring(3);
                  double lo=Integer.parseInt(strLo1)+Double.parseDouble(strlo2)/60;
                   System.out.println(lo);
               
                Statement st;
                Connection con = null;			 
        		try {
        			con = (Connection) handler.getServer().getDBPoolUtil().getConnection("jdbc");
        			st = (Statement) con.createStatement();
        			int val = st.executeUpdate("INSERT INTO gpsdata(deviceid, latitude, longitude, posdatetime) VALUES('" + Deviceid + "','" + la + "','" + lo + "','" + datetime + "')");
                    System.out.println("1 row Insertted");
        		} catch(Exception e) {
        			System.out.println(e);
        		} finally {
        			try	{
        				con.close();
        			} catch(Exception e) {
        				handler.sendSystemMsg("IGNORING: "+e);
        			}			
        		}                                  
            }
        }
		
		
		/*if(command.toLowerCase().equals("quit")) {
			handler.sendClientMsg("Bye ;-)");
			handler.closeConnection();
		} else {
			handler.sendClientMsg("Echo : "+command);
		}*/
	}
}
